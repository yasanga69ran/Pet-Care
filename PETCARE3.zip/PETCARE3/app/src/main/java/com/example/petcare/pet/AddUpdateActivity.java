package com.example.petcare.pet;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.petcare.R;

public class AddUpdateActivity extends AppCompatActivity {

    private EditText editTextPetName, editTextPetTitle, editTextPetAge, editTextPetSex, editTextContactNo, editTextLocation;
    private Button btnAddPet, btnUpdatePet, btnDeletePet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        editTextPetName = findViewById(R.id.name);
        editTextPetAge = findViewById(R.id.age);
        editTextPetTitle = findViewById(R.id.title);
        editTextPetSex = findViewById(R.id.sex);
        editTextContactNo = findViewById(R.id.contact);
        editTextLocation = findViewById(R.id.location);
        btnAddPet = findViewById(R.id.add_btn);
        btnUpdatePet = findViewById(R.id.up_btn);
        btnDeletePet = findViewById(R.id.de_btn);

        // Set OnClickListener for the Add button
        btnAddPet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addPet();
            }
        });

        // Set OnClickListener for the Update button
        btnUpdatePet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updatePet();
            }
        });

        // Set OnClickListener for the Delete button
        btnDeletePet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deletePet();
            }
        });
    }

    private void addPet() {
        // Get the values from EditText fields
        String name = editTextPetName.getText().toString().trim();
        String title = editTextPetTitle.getText().toString().trim();
        int age = Integer.parseInt(editTextPetAge.getText().toString().trim());
        String sex = editTextPetSex.getText().toString().trim();
        String contactNo = editTextContactNo.getText().toString().trim();
        String location = editTextLocation.getText().toString().trim();

        // Validate input
        if (name.isEmpty() || title.isEmpty() || sex.isEmpty() || contactNo.isEmpty() || location.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create a new PetModelClass instance
        PetModelClass pet = new PetModelClass();
        pet.setName(name);
        pet.setAge(age);
        pet.setTitle(title);
        pet.setSex(sex);
        pet.setContactNo(contactNo);
        pet.setLocation(location);

        // Add pet to the database
        long result = pet.addPet(this);


        if (result != -1) {
            Toast.makeText(this, "Pet added successfully", Toast.LENGTH_SHORT).show();
            clearFields();
        } else {
            Toast.makeText(this, "Failed to add pet", Toast.LENGTH_SHORT).show();
        }
    }

    private void updatePet() {
        // Get the values from EditText fields
        String name = editTextPetName.getText().toString().trim();
        String title = editTextPetTitle.getText().toString().trim();
        int age = Integer.parseInt(editTextPetAge.getText().toString().trim());
        String sex = editTextPetSex.getText().toString().trim();
        String contactNo = editTextContactNo.getText().toString().trim();
        String location = editTextLocation.getText().toString().trim();

        // Validate input
        if (name.isEmpty() || title.isEmpty() || sex.isEmpty() || contactNo.isEmpty() || location.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        long petId = 1;

        // Create a new PetModelClass instance
        PetModelClass pet = new PetModelClass();
        pet.setName(name);
        pet.setAge(age);
        pet.setTitle(title);
        pet.setSex(sex);
        pet.setContactNo(contactNo);
        pet.setLocation(location);

        // Update pet in the database
        int result = pet.updatePet(this);


        if (result > 0) {
            Toast.makeText(this, "Pet updated successfully", Toast.LENGTH_SHORT).show();
            clearFields();
        } else {
            Toast.makeText(this, "Failed to update pet", Toast.LENGTH_SHORT).show();
        }
    }

    private void deletePet() {

        long petId = 1;

        // Delete pet from the database
        int result = PetModelClass.deletePet(this, petId);

        if (result > 0) {
            Toast.makeText(this, "Pet deleted successfully", Toast.LENGTH_SHORT).show();
            clearFields();
        } else {
            Toast.makeText(this, "Failed to delete pet", Toast.LENGTH_SHORT).show();
        }
    }

    private void clearFields() {
        editTextPetName.setText("");
        editTextPetAge.setText("");
        editTextPetTitle.setText("");
        editTextPetSex.setText("");
        editTextContactNo.setText("");
        editTextLocation.setText("");
    }
}

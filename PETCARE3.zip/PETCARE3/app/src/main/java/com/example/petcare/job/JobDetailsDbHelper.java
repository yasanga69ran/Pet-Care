package com.example.petcare.job;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;

public class JobDetailsDbHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "JobDetails.db";
    private static final int DATABASE_VERSION = 1;

    public static class JobDetailsEntry implements BaseColumns {
        public static final String TABLE_NAME = "job_details";
        public static final String COLUMN_NAME = "name";
        public static final String COLUMN_EXPERIENCE = "experience";
    }

    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + JobDetailsEntry.TABLE_NAME + " (" +
                    JobDetailsEntry._ID + " INTEGER PRIMARY KEY," +
                    JobDetailsEntry.COLUMN_NAME + " TEXT," +
                    JobDetailsEntry.COLUMN_EXPERIENCE + " TEXT)";

    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + JobDetailsEntry.TABLE_NAME;

    public JobDetailsDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_ENTRIES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }
}

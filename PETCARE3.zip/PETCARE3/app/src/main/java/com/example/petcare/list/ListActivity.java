package com.example.petcare.list;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.petcare.R;

import java.util.ArrayList;

public class ListActivity extends AppCompatActivity {

    SearchView searchView;
    RecyclerView recyclerView;
    ArrayList<ModelClass> arrayList = new ArrayList<>();
    ArrayList<ModelClass> searchList;
    String[] nameList = new String[]{"Bella", "Luna", "Rocky", "Zoe", "Cody", "Molly", "Oscar", "Buddy", "Ruby", "Tiny", "Roo", "Zeus", "Lola", "Whiskers", "Rosie"};
    String[] titleList = new String[]{"Golden Retriever", "Labrador", "Siberian Husky", "Dalmatian", "German Shepherd", "Beagle", "Golden Retriever", "Labrador", "Golden Retriever", "Dalmatian", "German Shepherd", "Beagle", "Soft coat", "Soft coat", "Soft coat"};
    String[] ageList = new String[]{"1yr", "2yr", "1yr", "2yr", "1yr", "1yr", "1yr", "2yr", "1yr", "2yr", "1yr", "1yr", "2yr", "2yr", "1yr"};
    String[] sexList = new String[]{"Male", "Female", "Male", "Female", "Male", "Female", "Male", "Female", "Male", "Female", "Male", "Female", "Female", "Male", "Female"};
    String[] type = new String[]{"Dog", "Dog", "Dog", "Dog", "Dog", "Dog", "Dog", "Dog", "Dog", "Dog", "Dog", "Dog", "Cat", "Cat", "Cat"};
    String[] description = new String[]{
            "Bella is a friendly Golden Retriever with a soft, golden coat. She has a distinctive white patch on her chest and loves to play fetch in the backyard. Located at No. 22, Colombo 01, Boralla. Contact: 077-6767800. Price: $10,000.",
            "Luna is a striking Siberian Husky with mesmerizing blue eyes. She has a fluffy coat with unique markings on her face, making her stand out in a crowd. No. 12, Colombo 05, Thimbirigasyaya. 077-6767802. $11,000.",
            "Rocky is an energetic Boxer with a brindle coat. He has a playful personality and loves to go for runs in the park. Meet him at No. 28, Colombo 08, Borella. Contact: 077-6767803. Price: $9,800.",
            "Zoe is a gentle Dalmatian with distinctive black spots on a white coat. She enjoys socializing with other dogs at the local dog park. Visit her at No. 15, Colombo 04, Havelock Town. Contact: 077-6767804. Price: $10,500.",
            "Cody is a loyal German Shepherd with a sleek black and tan coat. He is known for his intelligence and protective nature. Find him at No. 35, Colombo 10, Maradana. Contact: 077-6767805. Price: $11,200.",
            "Molly is an affectionate Beagle with a tri-color coat. She loves to explore new scents during long walks. Discover her at No. 17, Colombo 06, Wellawatte. Contact: 077-6767806. Price: $9,300.",
            "Oscar is a 1-year-old Golden Retriever with a friendly demeanor and a soft, golden coat. He loves playing fetch in the backyard and can be found at No. 22, Colombo 01, Boralla. Contact: 077-6767800. Price: $10,000.",
            "Buddy, a 2-year-old Black Labrador, is a playful companion with a shiny coat. He enjoys long walks in the park and resides at No. 45, Colombo 03, Kollupitiya. Contact: 077-6767801. Price: $9,500.",
            "Ruby, a striking 1-year-old Siberian Husky with mesmerizing blue eyes, has a fluffy coat and unique markings on her face, making her stand out in a crowd. Visit her at No. 12, Colombo 05, Thimbirigasyaya. Contact: 077-6767802. Price: $11,000.",
            "Tiny, a 2-year-old Dalmatian, boasts distinctive black spots on a white coat. She enjoys socializing with other dogs at the local dog park and can be found at No. 15, Colombo 04, Havelock Town. Contact: 077-6767804. Price: $10,500.",
            "Roo is an energetic 1-year-old German Shepherd with a sleek black and tan coat. Known for intelligence and protective nature, he resides at No. 35, Colombo 10, Maradana. Contact: 077-6767805. Price: $11,200.",
            "Zeus, a 1-year-old Beagle, is an affectionate companion with a tri-color coat. He loves exploring new scents during long walks and can be found at No. 17, Colombo 06, Wellawatte. Contact: 077-6767806. Price: $9,300.",
            "Lola Whiskers, 2-year-old cats with soft coats, are delightful additions to any home. Lola resides at No. 28, Colombo 08, Borella, while Whiskers can be found at No. 45, Colombo 03, Kollupitiya. Contact: 077-6767801. Prices:$9,500.",
            "Whiskers,  2-year-old cats with soft coats, are delightful additions to any home. Lola resides at No. 28, Colombo 08, Borella, while Whiskers can be found at No. 45, Colombo 03, Kollupitiya.Contact: 077-6767803,Prices:$9,800,",
            "Rosie, a 1-year-old cat with a soft coat, completes the trio. She loves to play and can be found at No. 15, Colombo 04, Havelock Town. Contact: 077-6767804. Price: $10,500."
    };
    int[] imgList = new int[]{R.drawable.lab,
            R.drawable.lba,
            R.drawable.g,
            R.drawable.m,
            R.drawable.k,
            R.drawable.f,
            R.drawable.l,
            R.drawable.i,
            R.drawable.sh,
            R.drawable.h,
            R.drawable.be,
            R.drawable.odi,
            R.drawable.ctt,
            R.drawable.cttt,
            R.drawable.a};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        recyclerView = findViewById(R.id.recyclerView);
        searchView = findViewById(R.id.searchView);

        setupRecyclerView();

        for (int i = 0; i < nameList.length; i++) {
            ModelClass modelClass = new ModelClass();
            modelClass.setName(nameList[i]);
            modelClass.setTitle(titleList[i]);
            modelClass.setAge(ageList[i]);
            modelClass.setSex(sexList[i]);
            modelClass.setType(type[i]);
            modelClass.setImg(imgList[i]);
            modelClass.setDetailDescription1(description[i]);
            arrayList.add(modelClass);
        }


        PetAdapter petAdapter = new PetAdapter(ListActivity.this, arrayList, new PetAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                openDetailedActivity(arrayList.get(position));
            }
        });
        recyclerView.setAdapter(petAdapter);

        setSearchViewListener();
    }

    private void openDetailedActivity(ModelClass model) {
        Intent intent = new Intent(ListActivity.this, DetailedActivity.class);
        intent.putExtra("name", model.getName());
        intent.putExtra("title", model.getTitle());
        intent.putExtra("detail_description1", model.getDetailDescription1());
        intent.putExtra("detailImage", model.getImg());
        startActivity(intent);
    }

    private void setupRecyclerView() {
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(ListActivity.this);
        recyclerView.setLayoutManager(layoutManager);
    }

    private void setSearchViewListener() {
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                performSearch(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                performSearch(newText);
                return false;
            }
        });
    }

    private void performSearch(String query) {
        searchList = new ArrayList<>();

        if (!TextUtils.isEmpty(query)) {
            for (ModelClass model : arrayList) {
                if (model.getName().toUpperCase().contains(query.toUpperCase()) ||
                        model.getTitle().toUpperCase().contains(query.toUpperCase()) ||
                        model.getAge().toUpperCase().contains(query.toUpperCase()) ||
                        model.getSex().toUpperCase().contains(query.toUpperCase()) ||
                        model.getType().toUpperCase().contains(query.toUpperCase())) {
                    searchList.add(model);
                }
            }
        } else {
            searchList.addAll(arrayList);
        }

        PetAdapter petAdapter = new PetAdapter(ListActivity.this, searchList, new PetAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                openDetailedActivity(searchList.get(position));
            }
        });
        recyclerView.setAdapter(petAdapter);
    }

}

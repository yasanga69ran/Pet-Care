package com.example.petcare.review;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.petcare.R;

public class ReviewActivity extends AppCompatActivity {

    private EditText editTextReview;
    private Button btnSubmitReview;

    private ReviewDbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review);

        dbHelper = new ReviewDbHelper(this);

        editTextReview = findViewById(R.id.editTextReview);
        btnSubmitReview = findViewById(R.id.btnSubmitReview);
        LinearLayout reviewsContainer = findViewById(R.id.reviewsContainer);

        btnSubmitReview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                submitReview();
                loadReviews();
            }
        });

        // Load reviews initially
        loadReviews();
    }

    private void loadReviews() {
        try {
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            String[] projection = {
                    ReviewDbHelper.ReviewEntry.COLUMN_REVIEW_TEXT
            };

            Cursor cursor = db.query(
                    ReviewDbHelper.ReviewEntry.TABLE_NAME,
                    projection,
                    null,
                    null,
                    null,
                    null,
                    null
            );

            LinearLayout reviewsContainer = findViewById(R.id.reviewsContainer);
            reviewsContainer.removeAllViews(); // Clear previous reviews

            while (cursor.moveToNext()) {
                String reviewText = cursor.getString(cursor.getColumnIndexOrThrow(ReviewDbHelper.ReviewEntry.COLUMN_REVIEW_TEXT));

                // Create TextView to display review
                TextView reviewTextView = new TextView(this);
                reviewTextView.setText("Review: " + reviewText);
                reviewTextView.setTextSize(16);
                reviewTextView.setPadding(0, 0, 0, 16);

                // Add TextView to reviews container
                reviewsContainer.addView(reviewTextView);
            }

            cursor.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void submitReview() {
        try {
            String reviewText = editTextReview.getText().toString();

            // Save the review data to the Review database
            saveReview(reviewText);

            Toast.makeText(this, "Review submitted successfully", Toast.LENGTH_SHORT).show();

            // Clear the EditText
            editTextReview.setText("");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void saveReview(String reviewText) {
        try {
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(ReviewDbHelper.ReviewEntry.COLUMN_REVIEW_TEXT, reviewText);

            db.insert(ReviewDbHelper.ReviewEntry.TABLE_NAME, null, values);

            db.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

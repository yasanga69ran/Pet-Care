package com.example.petcare.pet;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;

public class PetDbHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "PetDatabase.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_NAME = "pets";
    public static final String COLUMN_ID = BaseColumns._ID;
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_AGE = "age";
    public static final String COLUMN_TITLE = "title";
    public static final String COLUMN_SEX = "sex";
    public static final String COLUMN_CONTACT_NO = "contact_no";
    public static final String COLUMN_LOCATION = "location";

    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY," +
                    COLUMN_NAME + " TEXT," +
                    COLUMN_AGE + " INTEGER," +
                    COLUMN_TITLE + " TEXT," +
                    COLUMN_SEX + " TEXT," +
                    COLUMN_CONTACT_NO + " TEXT," +
                    COLUMN_LOCATION + " TEXT)";

    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + TABLE_NAME;

    public PetDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_ENTRIES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }
}

package com.example.petcare.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.petcare.Home;
import com.example.petcare.databinding.ActivityLoginBinding;

public class LoginActivity extends AppCompatActivity {

    private static final String ADMIN_EMAIL = "admin@gmail.com";
    private static final String ADMIN_PASSWORD = "admin123";

    private static final String CAREGIVER_EMAIL = "caregiver@gmail.com";
    private static final String CAREGIVER_PASSWORD = "caregiver123";

    private static final String CUSTOMER_EMAIL = "customer@gmail.com";
    private static final String CUSTOMER_PASSWORD = "customer123";

    private ActivityLoginBinding binding;
    private DatabaseHelper databaseHelper;

    private static final String ALL_FIELDS_MANDATORY_MESSAGE = "All fields are mandatory";
    private static final String ADMIN_LOGIN_SUCCESS_MESSAGE = "Admin Login Successfully";
    private static final String CAREGIVER_LOGIN_SUCCESS_MESSAGE = "Caregiver Login Successfully";
    private static final String CUSTOMER_LOGIN_SUCCESS_MESSAGE = "Customer Login Successfully";
    private static final String LOGIN_SUCCESS_MESSAGE = "Login Successfully";
    private static final String INVALID_CREDENTIALS_MESSAGE = "Invalid Credentials";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        databaseHelper = new DatabaseHelper(this);

        binding.loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = binding.loginEmail.getText().toString();
                String password = binding.loginPassword.getText().toString();

                if (email.isEmpty() || password.isEmpty()) {
                    showToast(ALL_FIELDS_MANDATORY_MESSAGE);
                } else {
                    if (email.equals(ADMIN_EMAIL) && password.equals(ADMIN_PASSWORD)) {
                        showToast(ADMIN_LOGIN_SUCCESS_MESSAGE);
                        redirectToHomeActivity();
                    } else if (email.equals(CAREGIVER_EMAIL) && password.equals(CAREGIVER_PASSWORD)) {
                        showToast(CAREGIVER_LOGIN_SUCCESS_MESSAGE);
                        redirectToHomeActivity();
                    } else if (email.equals(CUSTOMER_EMAIL) && password.equals(CUSTOMER_PASSWORD)) {
                        showToast(CUSTOMER_LOGIN_SUCCESS_MESSAGE);
                        redirectToHomeActivity();
                    } else {
                        checkUserCredentials(email, password);
                    }
                }
            }
        });

        binding.signupRedirectText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                redirectToSignupActivity();
            }
        });
    }

    private void checkUserCredentials(String email, String password) {
        Boolean checkCredentials = databaseHelper.checkEmailPassword(email, password);

        if (checkCredentials) {
            showToast(LOGIN_SUCCESS_MESSAGE);
            redirectToHomeActivity();
        } else {
            showToast(INVALID_CREDENTIALS_MESSAGE);
        }
    }

    private void showToast(String message) {
        Toast.makeText(LoginActivity.this, message, Toast.LENGTH_SHORT).show();
    }

    private void redirectToHomeActivity() {
        Intent intent = new Intent(getApplicationContext(), Home.class);
        startActivity(intent);
    }

    private void redirectToSignupActivity() {
        Intent intent = new Intent(getApplicationContext(), SignupActivity.class);
        startActivity(intent);
    }
}

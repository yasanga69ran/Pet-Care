package com.example.petcare;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ChecklistActivity extends AppCompatActivity {

    private TextView titleTextView, dogsTitleTextView, bathingTextDogs, medicineTextDogs,
            vaccinationTextDogs, feedingTextDogs, groomingTextDogs;
    private ImageView bathingIconDogs, medicineIconDogs, vaccinationIconDogs, feedingIconDogs, groomingIconDogs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.care);

        // Initialize views
        titleTextView = findViewById(R.id.titleTextView);
        dogsTitleTextView = findViewById(R.id.dogsTitleTextView);
        bathingIconDogs = findViewById(R.id.bathingIconDogs);
        bathingTextDogs = findViewById(R.id.bathingTextDogs);
        medicineIconDogs = findViewById(R.id.medicineIconDogs);
        medicineTextDogs = findViewById(R.id.medicineTextDogs);
        vaccinationIconDogs = findViewById(R.id.vaccinationIconDogs);
        vaccinationTextDogs = findViewById(R.id.vaccinationTextDogs);
        feedingIconDogs = findViewById(R.id.feedingIconDogs);
        feedingTextDogs = findViewById(R.id.feedingTextDogs);
        groomingIconDogs = findViewById(R.id.groomingIconDogs);
        groomingTextDogs = findViewById(R.id.groomingTextDogs);

        // Set content for views
        titleTextView.setText("Pet Care Checklist");
        dogsTitleTextView.setText("Dogs and Cats");

        // Bathing Section
        bathingIconDogs.setImageResource(R.drawable.baseline_bathroom_24);
        bathingTextDogs.setText("Bathing: Keep your pets clean by giving them regular baths. This helps maintain their hygiene and prevents skin issues.");

        // Medicine Section
        medicineIconDogs.setImageResource(R.drawable.baseline_medication_24);
        medicineTextDogs.setText("Medicine: Administer prescribed medications to your pets on time to ensure their well-being and treat any health issues.");

        // Vaccination Section
        vaccinationIconDogs.setImageResource(R.drawable.baseline_vaccines_24);
        vaccinationTextDogs.setText("Vaccination: Ensure your pets are up-to-date on vaccinations to protect them from preventable diseases.");

        // Feeding Section
        feedingIconDogs.setImageResource(R.drawable.baseline_fastfood_24);
        feedingTextDogs.setText("Feeding: Provide a balanced diet to meet the nutritional needs of your pets for their overall health.");

        // Grooming Section
        groomingIconDogs.setImageResource(R.drawable.baseline_local_hospital_24);
        groomingTextDogs.setText("Grooming: Brush your pets regularly to keep their coat healthy and reduce shedding. It also strengthens your bond with them.");
    }
}

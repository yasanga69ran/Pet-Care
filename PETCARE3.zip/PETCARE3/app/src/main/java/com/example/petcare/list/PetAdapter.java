package com.example.petcare.list;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.petcare.R;

import java.util.ArrayList;

public class PetAdapter extends RecyclerView.Adapter<PetAdapter.MyHolder> {

    private Context context;
    private ArrayList<ModelClass> arrayList;
    private LayoutInflater layoutInflater;
    private OnItemClickListener listener;

    public PetAdapter(Context context, ArrayList<ModelClass> arrayList, OnItemClickListener listener) {
        this.context = context;
        this.arrayList = arrayList;
        this.listener = listener;
        layoutInflater = LayoutInflater.from(context);
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    @NonNull
    @Override
    public PetAdapter.MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = layoutInflater.inflate(R.layout.item_file, parent, false);
        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PetAdapter.MyHolder holder, @SuppressLint("RecyclerView") final int position) {
        ModelClass model = arrayList.get(position);
        holder.name.setText(model.getName());
        holder.title.setText(model.getTitle());
        holder.age.setText(model.getAge());
        holder.sex.setText(model.getSex());
        holder.img.setImageResource(model.getImg());

        // Set click listener
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onItemClick(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {
        TextView name, title, age, sex, contact;
        ImageView img;

        public MyHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.text);
            title = itemView.findViewById(R.id.text2);
            age = itemView.findViewById(R.id.text3);
            sex = itemView.findViewById(R.id.text4);
            contact = itemView.findViewById(R.id.text5);
            img = itemView.findViewById(R.id.img);
        }
    }
}

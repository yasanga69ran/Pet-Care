package com.example.petcare;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.petcare.job.JobDetailsActivity;
import com.example.petcare.list.ListActivity;
import com.example.petcare.login.LoginActivity;
import com.example.petcare.pet.AddUpdateActivity;
import com.example.petcare.review.ReviewActivity;

public class Home extends AppCompatActivity {
    private CardView search, Review, care, editPost, logout;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        search = findViewById(R.id.search);
        Review = findViewById(R.id.Review);
        care = findViewById(R.id.save);
        editPost = findViewById(R.id.editPost);
        logout = findViewById(R.id.logout);

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Home.this, ListActivity.class));
            }
        });

        Review.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Home.this, ReviewActivity.class));
            }
        });

        care.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Home.this, ChecklistActivity.class));
            }
        });

        editPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Home.this, AddUpdateActivity.class));
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logout();
            }
        });
    }

    private void logout() {
        getSharedPreferences("user_data", MODE_PRIVATE).edit().clear().apply();

        // Navigate to the login screen
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }
}

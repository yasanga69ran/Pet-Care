package com.example.petcare.pet;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.petcare.R;

public class PetActivity extends AppCompatActivity {
    public class Pet {
        private int id;
        private String name;
        private int age;
        private String title;
        private String sex;
        private String contactNo;
        private String location;


        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getAge() {
            return age;
        }

        public void setAge(int age) {
            this.age = age;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getSex() {
            return sex;
        }

        public void setSex(String sex) {
            this.sex = sex;
        }

        public String getContactNo() {
            return contactNo;
        }

        public void setContactNo(String contactNo) {
            this.contactNo = contactNo;
        }

        public String getLocation() {
            return location;
        }

        public void setLocation(String location) {
            this.location = location;
        }
    }


}
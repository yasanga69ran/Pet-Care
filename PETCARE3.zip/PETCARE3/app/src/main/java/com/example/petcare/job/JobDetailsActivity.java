package com.example.petcare.job;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.petcare.R;
import com.example.petcare.list.DetailedActivity;

public class JobDetailsActivity extends AppCompatActivity {

    private EditText editTextName, editTextExperience;
    private Button btnConfirmJob;

    private JobDetailsDbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_job_details);

        dbHelper = new JobDetailsDbHelper(this);

        editTextName = findViewById(R.id.editTextName);
        editTextExperience = findViewById(R.id.editTextExperience);
        btnConfirmJob = findViewById(R.id.btnConfirmJob);

        btnConfirmJob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirmJob();
            }
        });
    }

    private void confirmJob() {
        String caregiverName = editTextName.getText().toString();
        String caregiverExperience = editTextExperience.getText().toString();

        // Save the data to the JobDetails database
        saveJobDetails(caregiverName, caregiverExperience);

        // Show a toast message for successful job confirmation
        Toast.makeText(this, "Job confirmed successfully", Toast.LENGTH_SHORT).show();

        // Navigate back to DetailedActivity after job confirmation
        Intent intent = new Intent(JobDetailsActivity.this, DetailedActivity.class);
        startActivity(intent);
    }

    private void saveJobDetails(String name, String experience) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(JobDetailsDbHelper.JobDetailsEntry.COLUMN_NAME, name);
        values.put(JobDetailsDbHelper.JobDetailsEntry.COLUMN_EXPERIENCE, experience);

        db.insert(JobDetailsDbHelper.JobDetailsEntry.TABLE_NAME, null, values);

        db.close();
    }

    @Override
    public void onBackPressed() {
        // Show a toast message when navigating back
        Toast.makeText(this, "You are navigating back", Toast.LENGTH_SHORT).show();
        super.onBackPressed();
    }
}

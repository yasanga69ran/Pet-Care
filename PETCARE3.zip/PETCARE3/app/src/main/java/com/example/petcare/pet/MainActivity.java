package com.example.petcare.pet;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.petcare.R;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ImageView emptyImageView;
    private TextView noDataTextView;

    private List<PetModelClass> petList;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        // Initialize petList and petAdapter
        petList = new ArrayList<>();


        // Set up RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        // Load pets from the database
        loadPets();

        findViewById(R.id.add_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AddUpdateActivity.class));
            }
        });
    }

    private void loadPets() {
        // Retrieve all pets from the database
        petList.clear();
        petList.addAll(PetModelClass.getAllPets(this));

        // Update the UI based on whether there are pets or not
        if (petList.isEmpty()) {
            recyclerView.setVisibility(View.GONE);
            emptyImageView.setVisibility(View.VISIBLE);
            noDataTextView.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            emptyImageView.setVisibility(View.GONE);
            noDataTextView.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Reload pets when the activity is resumed
        loadPets();
    }
}

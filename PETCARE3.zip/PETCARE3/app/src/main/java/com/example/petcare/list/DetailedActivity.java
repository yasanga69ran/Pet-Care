package com.example.petcare.list;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.petcare.R;
import com.example.petcare.databinding.ActivityDetailedBinding;
import com.example.petcare.job.JobDetailsActivity;

// DetailedActivity.java

public class DetailedActivity extends AppCompatActivity {

    ActivityDetailedBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDetailedBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Intent intent = this.getIntent();
        if (intent != null) {
            String name = intent.getStringExtra("name");
            String title = intent.getStringExtra("title");
            String detail_description1 = intent.getStringExtra("detail_description1");
            int detailImage = intent.getIntExtra("detailImage", R.drawable.lab);

            binding.detailName.setText(name);
            binding.detailImage.setImageResource(detailImage);
            binding.detailDescription.setText(detail_description1);
        }

        binding.bookBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openJobDetailsActivity();
            }
        });
    }

    public void openJobDetailsActivity() {
        Intent intent = new Intent(this, JobDetailsActivity.class);
        startActivity(intent);
    }
}

package com.example.petcare.pet;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.provider.BaseColumns;

import java.util.ArrayList;
import java.util.List;

class PetModelClass {

    private int id;
    private String name;
    private int age;
    private String title;
    private String sex;
    private String contactNo;
    private String location;

    public PetModelClass() {
        // Default constructor
    }

    public PetModelClass(String name, int age, String title, String sex, String contactNo, String location) {
        this.name = name;
        this.age = age;
        this.title = title;
        this.sex = sex;
        this.contactNo = contactNo;
        this.location = location;
    }

    public static int deletePet(AddUpdateActivity addUpdateActivity, long petId) {
        return 0;
    }

    // Constructors, getters, and setters...

    public long addPet(Context context) {
        PetDbHelper dbHelper = new PetDbHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(PetDbHelper.COLUMN_NAME, getName());
        values.put(PetDbHelper.COLUMN_AGE, getAge());
        values.put(PetDbHelper.COLUMN_TITLE, getTitle());
        values.put(PetDbHelper.COLUMN_SEX, getSex());
        values.put(PetDbHelper.COLUMN_CONTACT_NO, getContactNo());
        values.put(PetDbHelper.COLUMN_LOCATION, getLocation());

        long newRowId = db.insert(PetDbHelper.TABLE_NAME, null, values);

        db.close();
        dbHelper.close();

        return newRowId;
    }

    public static List<PetModelClass> getAllPets(Context context) {
        List<PetModelClass> pets = new ArrayList<>();

        PetDbHelper dbHelper = new PetDbHelper(context);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.query(
                PetDbHelper.TABLE_NAME,
                null,
                null,
                null,
                null,
                null,
                null
        );

        while (cursor.moveToNext()) {
            PetModelClass pet = new PetModelClass();
            pet.setId(cursor.getInt(cursor.getColumnIndexOrThrow(PetDbHelper.COLUMN_ID)));
            pet.setName(cursor.getString(cursor.getColumnIndexOrThrow(PetDbHelper.COLUMN_NAME)));
            pet.setAge(cursor.getInt(cursor.getColumnIndexOrThrow(PetDbHelper.COLUMN_AGE)));
            pet.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(PetDbHelper.COLUMN_TITLE)));
            pet.setSex(cursor.getString(cursor.getColumnIndexOrThrow(PetDbHelper.COLUMN_SEX)));
            pet.setContactNo(cursor.getString(cursor.getColumnIndexOrThrow(PetDbHelper.COLUMN_CONTACT_NO)));
            pet.setLocation(cursor.getString(cursor.getColumnIndexOrThrow(PetDbHelper.COLUMN_LOCATION)));

            pets.add(pet);
        }

        cursor.close();
        db.close();
        dbHelper.close();

        return pets;
    }

    public int updatePet(Context context) {
        PetDbHelper dbHelper = new PetDbHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(PetDbHelper.COLUMN_NAME, getName());
        values.put(PetDbHelper.COLUMN_AGE, getAge());
        values.put(PetDbHelper.COLUMN_TITLE, getTitle());
        values.put(PetDbHelper.COLUMN_SEX, getSex());
        values.put(PetDbHelper.COLUMN_CONTACT_NO, getContactNo());
        values.put(PetDbHelper.COLUMN_LOCATION, getLocation());

        int rowsAffected = db.update(
                PetDbHelper.TABLE_NAME,
                values,
                PetDbHelper.COLUMN_ID + " = ?",
                new String[]{String.valueOf(getId())}
        );

        db.close();
        dbHelper.close();

        return rowsAffected;
    }

    public int deletePet(Context context) {
        PetDbHelper dbHelper = new PetDbHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        int rowsAffected = db.delete(
                PetDbHelper.TABLE_NAME,
                PetDbHelper.COLUMN_ID + " = ?",
                new String[]{String.valueOf(getId())}
        );

        db.close();
        dbHelper.close();

        return rowsAffected;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getContactNo() {
        return contactNo;
    }

    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
